<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Exercício 6</title>
</head>
<body>

	<?php
		$natal = 2004;
		$idade = (2020-2004);

		echo "Sua idade é ".$idade;
	?>

</body>
</html>