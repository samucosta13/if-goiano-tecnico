<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Exercício 2</title>
</head>
<body>
	<?php
		$num1 = 3;

		if ($num1%2 == 0) {
			echo "".$num1." é par";
		} else {
			echo "".$num1." é ímpar";
		}
	?>
</body>
</html>