<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Exercício 3</title>
</head>
<body>
	<?php

		$peso = 52;
		$altura = 1.72;

		$imc = $peso / ($altura * $altura);

		echo "IMC = ".$imc;
	?>
</body>
</html>