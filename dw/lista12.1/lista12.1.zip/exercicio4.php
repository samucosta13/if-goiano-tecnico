<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Exercício 4</title>
</head>
<body>

	<?php 
		$idade = 16;
		
		if ($idade < 18) {
			echo "Menor de idade ;-;";
		} else {
			echo "Maior de idade O_o";
		}
	?>

</body>
</html>