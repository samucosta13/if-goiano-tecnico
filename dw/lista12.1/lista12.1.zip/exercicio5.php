<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Exercício 5</title>
</head>
<body>

	<?php 
		$idade = 16;
		$natal = (2020 - $idade);
		echo "User nasceu em ".$natal;
	?>

</body>
</html>