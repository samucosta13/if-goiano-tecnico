<?php
	$nota1 = 7.1;
	$nota2 = 8;
	$nota3 = 9.5;
	$soma = ($nota1 + $nota2 + $nota3);
	$media = ($nota1 + $nota2 + $nota3)/3;
	echo "A soma das notas é ".$soma." <br>
	E a média aritmética delas é ".$media;
	// Perguntar como arredondar a exibição de valores de ponto flutuante (no ECHO)
?>