<?php
	$celsius = 15;
	$fahrenheit = ((9/5)*$celsius) + 32;
	echo $celsius."° C é o mesmo que ".$fahrenheit."° F";
?>